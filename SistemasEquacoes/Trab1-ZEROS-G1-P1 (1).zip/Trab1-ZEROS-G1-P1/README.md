# ResolucaoSistemasLineares
Repositório referente a técinas de Cáluculo Númerico referente a resolução de sistemas de equações lineares
